import React from "react";

export default function Header({ view, setView }) {
  return (
    <header className="app-header">
      <div className="brand">
        <div className="brand-mark">AV</div>
        <div className="brand-text">
          <div className="title">AIVOA Complaint Management</div>
          <div className="subtitle">API &amp; FDF Quality Assurance Module</div>
        </div>
      </div>
      <div className="header-tabs">
        <button className={view === "intake" ? "active" : ""} onClick={() => setView("intake")}>
          Log Complaint
        </button>
        <button className={view === "dashboard" ? "active" : ""} onClick={() => setView("dashboard")}>
          All Complaints
        </button>
      </div>
    </header>
  );
}
