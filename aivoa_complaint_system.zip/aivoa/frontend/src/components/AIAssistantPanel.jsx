import React, { useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { runExtractionText, runExtractionFile, setExtractionProgress } from "../store/complaintSlice";
import { postChatMessage, addUserMessageOptimistic } from "../store/chatSlice";

export default function AIAssistantPanel({ onToast }) {
  const dispatch = useDispatch();
  const { extraction, ai, form, sourceText } = useSelector((s) => s.complaint);
  const { sessionId, messages, status: chatStatus } = useSelector((s) => s.chat);

  const [dragging, setDragging] = useState(false);
  const [pasteOpen, setPasteOpen] = useState(false);
  const [pasteText, setPasteText] = useState("");
  const [chatInput, setChatInput] = useState("");
  const fileInputRef = useRef(null);

  const runFakeProgress = () => {
    // Purely cosmetic progress ticks while the request is in flight,
    // mirroring the extraction progress bar shown in the reference UI.
    let pct = 10;
    const timer = setInterval(() => {
      pct = Math.min(pct + 15, 90);
      dispatch(setExtractionProgress(pct));
    }, 350);
    return () => clearInterval(timer);
  };

  const handleFile = async (file) => {
    if (!file) return;
    const stop = runFakeProgress();
    try {
      await dispatch(runExtractionFile({ file, sessionId })).unwrap();
    } catch (e) {
      onToast?.("Extraction failed. Check backend logs / GROQ_API_KEY.", true);
    } finally {
      stop();
    }
  };

  const handlePasteSubmit = async () => {
    if (!pasteText.trim()) return;
    const stop = runFakeProgress();
    try {
      await dispatch(runExtractionText({ text: pasteText, sessionId })).unwrap();
      setPasteOpen(false);
      setPasteText("");
    } catch (e) {
      onToast?.("Extraction failed. Check backend logs / GROQ_API_KEY.", true);
    } finally {
      stop();
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    handleFile(file);
  };

  const handleSendChat = async () => {
    const text = chatInput.trim();
    if (!text) return;
    setChatInput("");
    dispatch(addUserMessageOptimistic(text));
    await dispatch(
      postChatMessage({ sessionId, message: text, complaintId: null, context: { ...form, source_text: sourceText } })
    );
  };

  const isLoading = extraction.status === "loading";

  return (
    <section className="panel">
      <div className="panel-header">
        <div>
          <h2>AI Complaint Intake Assistant</h2>
          <p className="sub">Drop complaint files or paste text below</p>
        </div>
        <span className="badge badge-teal">BETA</span>
      </div>

      <div className="assistant-body">
        <div
          className={`dropzone ${dragging ? "dragging" : ""}`}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="icon">📄</div>
          Drag &amp; drop complaint document here <br />
          or <span className="link">click to browse</span>
          <input
            ref={fileInputRef}
            type="file"
            hidden
            accept=".pdf,.docx,.txt,.eml"
            onChange={(e) => handleFile(e.target.files?.[0])}
          />
        </div>

        <div className="or-divider">OR</div>

        {!pasteOpen ? (
          <button className="paste-btn" onClick={() => setPasteOpen(true)}>📋 Paste Complaint Text / Email</button>
        ) : (
          <div>
            <textarea
              className="paste-textarea"
              placeholder="Paste the raw complaint email or text here..."
              value={pasteText}
              onChange={(e) => setPasteText(e.target.value)}
            />
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
              <button className="btn btn-primary btn-sm" onClick={handlePasteSubmit}>Extract</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setPasteOpen(false)}>Cancel</button>
            </div>
          </div>
        )}

        <div className="hint-box">
          Supported formats: PDF, DOCX, TXT, EML · Max file size: 10MB
        </div>

        {isLoading && (
          <div>
            <div className="progress-track"><div className="progress-fill" style={{ width: `${extraction.progress}%` }} /></div>
            <div className="progress-label">
              <span>Analyzing document content and extracting key details…</span>
              <span>{extraction.progress}%</span>
            </div>
          </div>
        )}

        <div className="ai-callout">
          <div className="avatar">✨</div>
          <div>
            {extraction.status === "success"
              ? "Complaint parsed successfully. I've extracted the product details, mapped the batch information, and generated an initial risk assessment for the complaint."
              : "Upload a complaint document or paste text above. I will automatically extract the details and populate the form for you."}
          </div>
        </div>

        {ai.completeness && !ai.completeness.is_complete && (
          <div className="insight-card" style={{ borderColor: "var(--amber-600)" }}>
            <h4>🧩 Completeness Check</h4>
            <p>{ai.completeness.notes}</p>
          </div>
        )}

        {ai.summary && (
          <div className="insight-card">
            <h4>📝 AI Complaint Summary</h4>
            <p>{ai.summary}</p>
          </div>
        )}

        {ai.rootCause && (
          <div className="insight-card">
            <h4>🔍 Root Cause Recommendation</h4>
            <p>{ai.rootCause}</p>
          </div>
        )}

        {ai.capa && (
          <div className="insight-card">
            <h4>✅ CAPA Recommendation</h4>
            <p>{ai.capa}</p>
          </div>
        )}

        <div className="chat-thread">
          {messages.length === 0 && (
            <div className="chat-bubble assistant">Ask me anything about this complaint, or about how QMS complaint handling works.</div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`chat-bubble ${m.role === "user" ? "user" : "assistant"}`}>{m.content}</div>
          ))}
          {chatStatus === "loading" && <div className="chat-bubble assistant"><span className="spinner" style={{ borderTopColor: "var(--ink-500)", borderColor: "rgba(0,0,0,0.15)" }} /></div>}
        </div>

        <div className="chat-input-row">
          <input
            placeholder="Ask me anything about this complaint..."
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSendChat()}
          />
          <button className="chat-send" onClick={handleSendChat} disabled={!chatInput.trim()}>➤</button>
        </div>
        <div className="chat-disclaimer">Powered by LangGraph + Groq · AI responses may contain errors. Please verify information.</div>
      </div>
    </section>
  );
}
