import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { setField, saveComplaint, resetForm } from "../store/complaintSlice";

const SOURCE_OPTIONS = ["Email", "Phone", "Customer Portal", "Field Representative", "Distributor", "Other"];
const TYPE_OPTIONS = [
  "Quality Deviation",
  "Adverse Event",
  "Packaging Defect",
  "Efficacy Issue",
  "Contamination",
  "Labeling Error",
  "Other",
];
const SEVERITY_OPTIONS = ["Minor", "Major", "Critical"];
const PRIORITY_OPTIONS = ["Low", "Medium", "High", "Urgent"];

function statusBadge(status) {
  const map = {
    "Pending Triage": "badge-amber",
    "Ready to Commit": "badge-green",
    Committed: "badge-teal",
  };
  return map[status] || "badge-amber";
}

export default function ComplaintForm({ onSaved, onToast }) {
  const dispatch = useDispatch();
  const { form, aiFilledFields, ai, save } = useSelector((s) => s.complaint);

  const isReadyToCommit = ai.completeness?.is_complete;
  const status = save.status === "success" ? "Committed" : isReadyToCommit ? "Ready to Commit" : "Pending Triage";

  const handleChange = (field) => (e) => {
    dispatch(setField({ field, value: e.target.value }));
  };

  const cls = (field) => (aiFilledFields.includes(field) ? "ai-filled" : "");

  const handleCommit = async () => {
    const result = await dispatch(saveComplaint());
    if (result.meta.requestStatus === "fulfilled") {
      onToast?.("Complaint committed to the QMS ledger.");
      onSaved?.();
    } else {
      onToast?.("Could not save the complaint. Check the backend logs.", true);
    }
  };

  return (
    <section className="panel">
      <div className="panel-header">
        <div>
          <h2>Log Customer Complaint</h2>
          <p className="sub">API &amp; FDF Quality Assurance Module</p>
        </div>
        <span className={`badge ${statusBadge(status)}`}>{status}</span>
      </div>

      <div className="form-body">
        <div className="form-section">
          <div className="form-section-label"><span className="num">1</span> Origin &amp; Customer Details</div>
          <div className="form-grid">
            <div className="field">
              <label>Complaint Source</label>
              <select className={cls("complaint_source")} value={form.complaint_source} onChange={handleChange("complaint_source")}>
                <option value="">Awaiting AI extraction...</option>
                {SOURCE_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Customer Name</label>
              <input className={cls("customer_name")} placeholder="Awaiting AI extraction..." value={form.customer_name} onChange={handleChange("customer_name")} />
            </div>
          </div>
        </div>

        <div className="form-section">
          <div className="form-section-label"><span className="num">2</span> Product &amp; Batch Identification</div>
          <div className="form-grid">
            <div className="field">
              <label>Product Name</label>
              <input className={cls("product_name")} placeholder="Awaiting AI extraction..." value={form.product_name} onChange={handleChange("product_name")} />
            </div>
            <div className="field">
              <label>Product Strength/Grade</label>
              <input className={cls("product_strength_grade")} placeholder="Awaiting AI extraction..." value={form.product_strength_grade} onChange={handleChange("product_strength_grade")} />
            </div>
            <div className="field">
              <label>Batch / Lot Number</label>
              <input className={cls("batch_lot_number")} placeholder="Awaiting AI extraction..." value={form.batch_lot_number} onChange={handleChange("batch_lot_number")} />
            </div>
            <div className="field">
              <label>Manufacturing Date</label>
              <input className={cls("manufacturing_date")} placeholder="Awaiting AI extraction..." value={form.manufacturing_date} onChange={handleChange("manufacturing_date")} />
            </div>
            <div className="field">
              <label>Expiry Date</label>
              <input className={cls("expiry_date")} placeholder="Awaiting AI extraction..." value={form.expiry_date} onChange={handleChange("expiry_date")} />
            </div>
            <div className="field">
              <label>Quantity Affected</label>
              <input className={cls("quantity_affected")} placeholder="Awaiting AI extraction..." value={form.quantity_affected} onChange={handleChange("quantity_affected")} />
            </div>
          </div>
        </div>

        <div className="form-section">
          <div className="form-section-label"><span className="num">3</span> Complaint Details</div>
          <div className="form-grid">
            <div className="field">
              <label>Complaint Type</label>
              <select className={cls("complaint_type")} value={form.complaint_type} onChange={handleChange("complaint_type")}>
                <option value="">Awaiting AI extraction...</option>
                {TYPE_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Complaint Date</label>
              <input className={cls("complaint_date")} placeholder="Awaiting AI extraction..." value={form.complaint_date} onChange={handleChange("complaint_date")} />
            </div>
            <div className="field full">
              <label>Detailed Complaint Description</label>
              <textarea className={cls("detailed_description")} placeholder="AI will synthesize the complaint into a formal QMS description..." value={form.detailed_description} onChange={handleChange("detailed_description")} />
            </div>
          </div>
        </div>

        <div className="form-section">
          <div className="form-section-label"><span className="num">4</span> Initial Assessment &amp; Priority</div>

          {ai.riskClassification && (
            <div className="insight-card" style={{ marginBottom: 14 }}>
              <h4>🤖 AI Copilot Risk Assessment</h4>
              <p>{ai.riskClassification}</p>
            </div>
          )}

          <div className="form-grid">
            <div className="field">
              <label>Initial Severity</label>
              <select className={cls("initial_severity")} value={form.initial_severity} onChange={handleChange("initial_severity")}>
                <option value="">Select...</option>
                {SEVERITY_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Priority</label>
              <select className={cls("priority")} value={form.priority} onChange={handleChange("priority")}>
                <option value="">Select...</option>
                {PRIORITY_OPTIONS.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            </div>
          </div>
        </div>

        {ai.duplicateOf && (
          <div className="insight-card" style={{ borderColor: "var(--amber-600)", marginBottom: 18 }}>
            <h4>⚠ Possible Duplicate</h4>
            <p>Matches existing complaint <code>{ai.duplicateOf}</code>. {ai.duplicateReason}</p>
          </div>
        )}

        <div className="form-actions">
          <button className="btn btn-ghost" onClick={() => dispatch(resetForm())}>Reset Form</button>
          <button className="btn btn-primary" disabled={save.status === "loading"} onClick={handleCommit}>
            {save.status === "loading" ? <span className="spinner" /> : "💾"} Save Complaint
          </button>
        </div>
      </div>
    </section>
  );
}
