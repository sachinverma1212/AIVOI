import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchComplaints, runBonusAction, selectComplaint } from "../store/complaintSlice";

function severityBadge(sev) {
  if (sev === "Critical") return "badge-red";
  if (sev === "Major") return "badge-amber";
  return "badge-green";
}

export default function ComplaintsList({ onToast }) {
  const dispatch = useDispatch();
  const { items, status } = useSelector((s) => s.complaint.list);
  const selected = useSelector((s) => s.complaint.selectedComplaint);

  useEffect(() => {
    dispatch(fetchComplaints());
  }, [dispatch]);

  const runAction = async (action, id) => {
    const result = await dispatch(runBonusAction({ action, complaintId: id }));
    if (result.meta.requestStatus === "fulfilled") {
      onToast?.(`${action.replace("_", " ")} updated.`);
    } else {
      onToast?.("Action failed. Check backend logs.", true);
    }
  };

  return (
    <div>
      <div className="dashboard-toolbar">
        <div>
          <h1>All Complaints</h1>
          <p>{items.length} record{items.length === 1 ? "" : "s"} in the QMS ledger</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={() => dispatch(fetchComplaints())}>
          ⟳ Refresh
        </button>
      </div>

      {status === "loading" && <div className="empty-state">Loading complaints…</div>}

      {status === "success" && items.length === 0 && (
        <div className="empty-state">
          No complaints logged yet. Go to <strong>Log Complaint</strong> to create your first record.
        </div>
      )}

      {items.length > 0 && (
        <table className="complaint-table">
          <thead>
            <tr>
              <th>Product / Batch</th>
              <th>Customer</th>
              <th>Type</th>
              <th>Severity</th>
              <th>Priority</th>
              <th>Status</th>
              <th>AI Tools</th>
            </tr>
          </thead>
          <tbody>
            {items.map((c) => (
              <tr key={c.id} onClick={() => dispatch(selectComplaint(c))}>
                <td>
                  <strong>{c.product_name || "—"}</strong>
                  <div style={{ color: "var(--ink-500)", fontSize: 11.5 }}>{c.batch_lot_number || "no batch #"}</div>
                </td>
                <td>{c.customer_name || "—"}</td>
                <td>{c.complaint_type || "—"}</td>
                <td><span className={`badge ${severityBadge(c.initial_severity)}`}>{c.initial_severity || "—"}</span></td>
                <td>{c.priority || "—"}</td>
                <td>{c.status}</td>
                <td onClick={(e) => e.stopPropagation()}>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => runAction("summary", c.id)}>Summarize</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => runAction("root_cause", c.id)}>Root Cause</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => runAction("capa", c.id)}>CAPA</button>
                    <button className="btn btn-ghost btn-sm" onClick={() => runAction("duplicate", c.id)}>Check Dup.</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {selected && (
        <div className="panel" style={{ marginTop: 20 }}>
          <div className="panel-header">
            <h2>{selected.product_name} — {selected.batch_lot_number}</h2>
            <button className="btn btn-ghost btn-sm" onClick={() => dispatch(selectComplaint(null))}>Close</button>
          </div>
          <div className="form-body">
            {selected.ai_summary && <div className="insight-card" style={{ marginBottom: 12 }}><h4>📝 Summary</h4><p>{selected.ai_summary}</p></div>}
            {selected.ai_root_cause && <div className="insight-card" style={{ marginBottom: 12 }}><h4>🔍 Root Cause</h4><p>{selected.ai_root_cause}</p></div>}
            {selected.ai_capa && <div className="insight-card" style={{ marginBottom: 12 }}><h4>✅ CAPA</h4><p>{selected.ai_capa}</p></div>}
            {selected.ai_duplicate_of && <div className="insight-card"><h4>⚠ Duplicate</h4><p>Matches complaint {selected.ai_duplicate_of}</p></div>}
            {!selected.ai_summary && !selected.ai_root_cause && !selected.ai_capa && (
              <p style={{ color: "var(--ink-500)", fontSize: 13 }}>No AI insights generated yet — use the AI Tools buttons above.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
