import React, { useState, useCallback } from "react";
import Header from "./components/Header";
import ComplaintForm from "./components/ComplaintForm";
import AIAssistantPanel from "./components/AIAssistantPanel";
import ComplaintsList from "./components/ComplaintsList";
import { useDispatch } from "react-redux";
import { resetForm } from "./store/complaintSlice";
import { resetChat } from "./store/chatSlice";

export default function App() {
  const [view, setView] = useState("intake");
  const [toast, setToast] = useState(null);
  const dispatch = useDispatch();

  const showToast = useCallback((message, isError = false) => {
    setToast({ message, isError });
    setTimeout(() => setToast(null), 3500);
  }, []);

  const handleSaved = () => {
    dispatch(resetForm());
    dispatch(resetChat());
    setView("dashboard");
  };

  return (
    <div className="app-shell">
      <Header view={view} setView={setView} />
      <main className="app-body">
        {view === "intake" ? (
          <div className="workspace">
            <ComplaintForm onSaved={handleSaved} onToast={showToast} />
            <AIAssistantPanel onToast={showToast} />
          </div>
        ) : (
          <ComplaintsList onToast={showToast} />
        )}
      </main>
      {toast && <div className={`toast ${toast.isError ? "error" : ""}`}>{toast.message}</div>}
    </div>
  );
}
