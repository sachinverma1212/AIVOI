import axios from "axios";

const api = axios.create({ baseURL: "/api" });

export const extractFromText = (text, sessionId) =>
  api.post("/extract/text", { text, session_id: sessionId }).then((r) => r.data);

export const extractFromFile = (file, sessionId) => {
  const form = new FormData();
  form.append("file", file);
  form.append("session_id", sessionId);
  return api.post("/extract/file", form).then((r) => r.data);
};

export const listComplaints = () => api.get("/complaints").then((r) => r.data);
export const getComplaint = (id) => api.get(`/complaints/${id}`).then((r) => r.data);
export const createComplaint = (payload) => api.post("/complaints", payload).then((r) => r.data);
export const updateComplaint = (id, payload) => api.put(`/complaints/${id}`, payload).then((r) => r.data);
export const deleteComplaint = (id) => api.delete(`/complaints/${id}`).then((r) => r.data);

export const sendChatMessage = (sessionId, message, complaintId, context) =>
  api
    .post("/chat", { session_id: sessionId, message, complaint_id: complaintId, context })
    .then((r) => r.data);

export const regenerateSummary = (complaintId) => api.post("/ai/summary", { complaint_id: complaintId }).then((r) => r.data);
export const regenerateRootCause = (complaintId) => api.post("/ai/root-cause", { complaint_id: complaintId }).then((r) => r.data);
export const regenerateCapa = (complaintId) => api.post("/ai/capa", { complaint_id: complaintId }).then((r) => r.data);
export const regenerateRisk = (complaintId) => api.post("/ai/risk", { complaint_id: complaintId }).then((r) => r.data);
export const checkDuplicate = (complaintId) => api.post("/ai/duplicate-check", { complaint_id: complaintId }).then((r) => r.data);

export default api;
