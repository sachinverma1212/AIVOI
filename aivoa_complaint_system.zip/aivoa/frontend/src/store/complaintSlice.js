import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import * as api from "../api/client";

export const EMPTY_FORM = {
  complaint_source: "",
  customer_name: "",
  product_name: "",
  product_strength_grade: "",
  batch_lot_number: "",
  manufacturing_date: "",
  expiry_date: "",
  quantity_affected: "",
  complaint_type: "",
  complaint_date: "",
  detailed_description: "",
  initial_severity: "",
  priority: "",
  status: "Pending Triage",
};

export const runExtractionText = createAsyncThunk(
  "complaint/extractText",
  async ({ text, sessionId }) => api.extractFromText(text, sessionId)
);

export const runExtractionFile = createAsyncThunk(
  "complaint/extractFile",
  async ({ file, sessionId }) => api.extractFromFile(file, sessionId)
);

export const saveComplaint = createAsyncThunk(
  "complaint/save",
  async (_, { getState }) => {
    const { form, sourceText, ai } = getState().complaint;
    const payload = {
      ...form,
      source_text: sourceText,
    };
    return api.createComplaint(payload).then((saved) => ({ saved, ai }));
  }
);

export const fetchComplaints = createAsyncThunk("complaint/list", async () => api.listComplaints());

export const runBonusAction = createAsyncThunk(
  "complaint/bonusAction",
  async ({ action, complaintId }) => {
    const fn = {
      summary: api.regenerateSummary,
      root_cause: api.regenerateRootCause,
      capa: api.regenerateCapa,
      risk: api.regenerateRisk,
      duplicate: api.checkDuplicate,
    }[action];
    return fn(complaintId);
  }
);

const initialState = {
  form: { ...EMPTY_FORM },
  sourceText: "",
  aiFilledFields: [],
  ai: {
    completeness: null,
    riskClassification: null,
    duplicateOf: null,
    duplicateReason: null,
    summary: null,
    rootCause: null,
    capa: null,
  },
  extraction: { status: "idle", progress: 0, error: null },
  save: { status: "idle", error: null, lastSavedId: null },
  list: { items: [], status: "idle" },
  selectedComplaint: null,
};

const complaintSlice = createSlice({
  name: "complaint",
  initialState,
  reducers: {
    setField(state, action) {
      const { field, value } = action.payload;
      state.form[field] = value;
      state.aiFilledFields = state.aiFilledFields.filter((f) => f !== field);
    },
    resetForm(state) {
      state.form = { ...EMPTY_FORM };
      state.sourceText = "";
      state.aiFilledFields = [];
      state.ai = initialState.ai;
      state.extraction = { status: "idle", progress: 0, error: null };
      state.save = { status: "idle", error: null, lastSavedId: null };
    },
    setExtractionProgress(state, action) {
      state.extraction.progress = action.payload;
    },
    selectComplaint(state, action) {
      state.selectedComplaint = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(runExtractionText.pending, (state) => {
        state.extraction = { status: "loading", progress: 10, error: null };
      })
      .addCase(runExtractionFile.pending, (state) => {
        state.extraction = { status: "loading", progress: 10, error: null };
      })
      .addCase(runExtractionText.fulfilled, applyExtractionResult)
      .addCase(runExtractionFile.fulfilled, applyExtractionResult)
      .addCase(runExtractionText.rejected, (state, action) => {
        state.extraction = { status: "error", progress: 0, error: action.error.message };
      })
      .addCase(runExtractionFile.rejected, (state, action) => {
        state.extraction = { status: "error", progress: 0, error: action.error.message };
      })
      .addCase(saveComplaint.pending, (state) => {
        state.save = { status: "loading", error: null, lastSavedId: null };
      })
      .addCase(saveComplaint.fulfilled, (state, action) => {
        state.save = { status: "success", error: null, lastSavedId: action.payload.saved.id };
      })
      .addCase(saveComplaint.rejected, (state, action) => {
        state.save = { status: "error", error: action.error.message, lastSavedId: null };
      })
      .addCase(fetchComplaints.pending, (state) => {
        state.list.status = "loading";
      })
      .addCase(fetchComplaints.fulfilled, (state, action) => {
        state.list.status = "success";
        state.list.items = action.payload;
      })
      .addCase(runBonusAction.fulfilled, (state, action) => {
        const updated = action.payload;
        state.list.items = state.list.items.map((c) => (c.id === updated.id ? updated : c));
        if (state.selectedComplaint?.id === updated.id) state.selectedComplaint = updated;
      });
  },
});

function applyExtractionResult(state, action) {
  const data = action.payload;
  const extracted = data.extracted || {};
  const filled = [];
  Object.entries(extracted).forEach(([key, value]) => {
    if (value !== null && value !== undefined && String(value).trim() !== "") {
      state.form[key] = value;
      filled.push(key);
    }
  });
  state.aiFilledFields = filled;
  state.sourceText = data.source_text || state.sourceText;
  state.ai = {
    completeness: data.completeness,
    riskClassification: data.risk_classification,
    duplicateOf: data.duplicate_of,
    duplicateReason: data.duplicate_reason,
    summary: data.summary,
    rootCause: data.root_cause,
    capa: data.capa,
  };
  state.extraction = { status: "success", progress: 100, error: null };
}

export const { setField, resetForm, setExtractionProgress, selectComplaint } = complaintSlice.actions;
export default complaintSlice.reducer;
