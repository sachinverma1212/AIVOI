import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import * as api from "../api/client";

export const postChatMessage = createAsyncThunk(
  "chat/send",
  async ({ sessionId, message, complaintId, context }) =>
    api.sendChatMessage(sessionId, message, complaintId, context)
);

const initialState = {
  sessionId: `session-${Date.now()}`,
  messages: [],
  status: "idle",
  error: null,
};

const chatSlice = createSlice({
  name: "chat",
  initialState,
  reducers: {
    resetChat(state) {
      state.sessionId = `session-${Date.now()}`;
      state.messages = [];
      state.status = "idle";
      state.error = null;
    },
    addUserMessageOptimistic(state, action) {
      state.messages.push({ role: "user", content: action.payload });
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(postChatMessage.pending, (state) => {
        state.status = "loading";
      })
      .addCase(postChatMessage.fulfilled, (state, action) => {
        state.status = "success";
        state.messages = action.payload.history;
      })
      .addCase(postChatMessage.rejected, (state, action) => {
        state.status = "error";
        state.error = action.error.message;
        state.messages.push({
          role: "assistant",
          content: "I ran into an error reaching the AI service. Please check your Groq API key and try again.",
        });
      });
  },
});

export const { resetChat, addUserMessageOptimistic } = chatSlice.actions;
export default chatSlice.reducer;
